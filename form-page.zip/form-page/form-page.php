<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Form-Page</title>
</head>
<body>
<h1>FORM PAGE</h1>



        <div>
                <div">
                    <div>
                        <form id="contact-form" name="contact_form" class="default-form" action="inc/sendmail.php" method="post" novalidate="novalidate">
                            <div>
                                <div>
                                    <input type="text" name="form_name" value="" placeholder="Your Name*" required="" aria-required="true">
                                </div><br>
                                <div>
                                    <input type="email" name="form_email" value="" placeholder="Your Mail*" required="" aria-required="true">
                                </div><br>
                            </div>
                            <div><br>
                                <div>
                                    <input type="text" name="form_phone" value="" placeholder="Phone">
                                </div><br>
                                <div>
                                    <input type="text" name="form_subject" value="" placeholder="Subject">
                                </div>
                            </div><br>
                            <div class="row">
                                <div>
                                    <textarea name="form_message" placeholder="Your Message.." required="" aria-required="true"></textarea>
                                </div>
                            </div>
                            <div><br>s
                                <div >
                                    <input id="form_botcheck" name="form_botcheck" class="form-control" type="hidden" value="">
                                    <button class="thm-btn bg-clr1" type="submit" data-loading-text="Please wait...">send message</button>
                                </div>
                            </div>
                        </form>  
                    </div>
                </div>
                    
            </div>
</body>
</html>